class Tag:
    def __init__(self, name, color='#007bff'):
        self.id = None
        self.name = name
        self.color = color