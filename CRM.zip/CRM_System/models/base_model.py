class BaseModel:
    pass