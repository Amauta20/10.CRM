class ContactTag:
    def __init__(self, contact_id, tag_id):
        self.contact_id = contact_id
        self.tag_id = tag_id